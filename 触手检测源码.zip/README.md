#### Vue + Vant + HTML5 Plus

1、安装依赖

```shell
npm install
```

2、网页端调试

```shell
npm run serve
```

3、打包发行

```shell
npm run build
```

4、发布App（HBuild X）

。。。。

**注意：**不能直接在网页端运行某些功能，依赖手机端 API